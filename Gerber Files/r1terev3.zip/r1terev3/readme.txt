8:36PM 7-6-2010

Project Name	=	replica 1 TE revision 3

Files:

r1terev3.GBS	=	Bottom SolderMask
r1terev3.GTL	=	Top Layer
r1terev3.GTO	=	Top Overlay
r1terev3.GTS	=	Top Soldermask
r1terev3.TXT	=	Ascii Drill file
readme.txt	=	This file

Contact Info:

Vince Briel
Briel Computers
5392 Cornell Blvd
North Ridgeville, OH 44039
E-Mail: vbriel@yahoo.com
Phone: (440) 382-8517
