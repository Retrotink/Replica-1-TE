The programs listed here are to be loaded while in BASIC.

To load:

Power up the replica 1, press RESET button.

Type 'E000R' and then Enter key.

Transfer the program with your terminal program (Hyperterminal) as described in the replica 1 Manual.

Once the program is downloaded, it will run automatically.